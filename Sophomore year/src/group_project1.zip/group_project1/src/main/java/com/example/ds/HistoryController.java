package com.example.ds;

import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import org.json.*;

import java.io.IOException;
import java.util.ArrayList;


public class HistoryController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private ListView<String> transfersHistory;

    //String[] transfersHistory= {"Card 1", "Card 2", "Card 3", "Card 4", "Card 5"};

    @FXML
    public void initialize() throws UnirestException {
        System.out.println("transfers history window");


        ArrayList<String> historyPayments = new ArrayList();
        JSONArray results = Unirest.post(ApiEndpoints.MONEY_TRANSFER_HISTORY_API)
                .header("accept", "application/json")
                .field("cardExpiryDate", CardCredentials.CARD_EXPIRY_DATE)
                .field("cardNumber", CardCredentials.CARD_NUMBER)
                .field("cardCvv", CardCredentials.CARD_CVV).asJson().getBody().getArray();

        for(int i=0; i<results.length(); i++){
            historyPayments.add("id: " + results.getJSONObject(i).getInt("id") + " | cardSent: " + results.getJSONObject(i).getString("cardSent") + " | cardReceived: " + results.getJSONObject(i).getString("cardReceived") + " | amount: " + results.getJSONObject(i).getDouble("amount"));
        }

        for(int i=0; i<historyPayments.size(); i++){
            transfersHistory.getItems().add(historyPayments.get(i));
        }

     }

    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToScene2(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Transfer.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToScene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("History.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
