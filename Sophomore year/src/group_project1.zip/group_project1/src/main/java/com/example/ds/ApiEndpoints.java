/**
 * Created by IntelliJ IDEA.<br/>
 * User: javokhir<br/>
 * Date: 29/11/21<br/>
 * Time: 13:07<br/>
 * ID: U2010257<br/>
 * Telegram: @ShJavohir<br/>
 * Github: https://github.com/ShJavokhir<br/>
 */

package com.example.ds;

/**
 * Created by IntelliJ IDEA.<br/>
 * User: javokhir<br/>
 * Date: 29/11/21<br/>
 * Time: 13:07<br/>
 */
public class ApiEndpoints {
    public static String BASE_URL = "http://localhost:3000";
    public static String GET_BALANCE_API = BASE_URL + "/" + "card/virtual/getBalance";
    public static String GET_CASHBACK_API = BASE_URL + "/" + "card/virtual/getCashback";
    public static String TRANSFER_MONEY_API = BASE_URL + "/" + "transaction";
    public static String MONEY_TRANSFER_HISTORY_API = BASE_URL + "/" + "transaction/getCardTransfers";

}
