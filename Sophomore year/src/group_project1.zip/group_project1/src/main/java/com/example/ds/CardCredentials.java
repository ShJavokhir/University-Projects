/**
 * Created by IntelliJ IDEA.<br/>
 * User: javokhir<br/>
 * Date: 29/11/21<br/>
 * Time: 12:26<br/>
 * ID: U2010257<br/>
 * Telegram: @ShJavohir<br/>
 * Github: https://github.com/ShJavokhir<br/>
 */

package com.example.ds;

/**
 * Created by IntelliJ IDEA.<br/>
 * User: javokhir<br/>
 * Date: 29/11/21<br/>
 * Time: 12:26<br/>
 */
public class CardCredentials {
    public static String CARD_NUMBER = "7375259351429789";
    public static String CARD_EXPIRY_DATE = "05/25";
    public static String CARD_CVV = "564";
}
