package com.example.ds;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class HController {

    @FXML
    private Button history1;

    @FXML
    private Button transfer1;

    @FXML
    private Label balance;

    @FXML
    private Label cashback;

}
