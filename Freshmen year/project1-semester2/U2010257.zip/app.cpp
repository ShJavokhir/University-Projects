/*
    Started at 17:45 01.05.2021
    Finished at 21:27 01.05.2021
    Total lines of code: 500
    
    Team project: Flyght Ticket booking
    Team members:
        Sobitov Ilyar U2010267 
        Tulaganov Qobiljon U2010285 
        Javokhir Shomuratov U2010257  
    Section number: 002
*/


#include <iostream>
#include <fstream>
#include<windows.h>

//#include <unistd.h>

using namespace std;

static string INPUT_SHOULD_BE_DIGIT_EXCEPTION = "Input should be digit !";
static string INCORRECT_MENU_EXCEPTION = "You have entered incorrect menu number !";

class Ticket
{
private:
    string toWhere;
    int seatNumber;
    double price;

public:
    void setData(string toWhere, int seatNumber, double price)
    {
        this->toWhere = toWhere;
        this->seatNumber = seatNumber;
        this->price = price;
    }
    void printData()
    {
        cout << "Flying to: " << toWhere << " Seat number: " << seatNumber << " Price: " << price << endl;
    }
};

Ticket ticket;

class Exception
{
public:
    void showError(string message)
    {
        system("cls");
        cout << " ----------------------------------------------" << endl;
        cout << "|==================| ERROR |==================|" << endl;
        cout << " ----------------------------------------------" << endl;
        cout << "  " << message << endl;
        cout << " ----------------------------------------------" << endl;
        cout << "|:::::::: Flyght Ticket Booking System ::::::::|" << endl;
        cout << " ----------------------------------------------" << endl;
        Sleep(2000);
    }
};

class GeneralFunctions : protected Exception
{
public:
    void aboutMenu()
    {
        system("cls");
        cout << " ----------------------------------------------" << endl;
        cout << "|=================| AUTHORS |==================|" << endl;
        cout << " ----------------------------------------------" << endl;
        cout << "| Sobitov Ilyar U2010267                       |" << endl;
        cout << "| Tulaganov Qobiljon U2010285                  |" << endl;
        cout << "| Javokhir Shomuratov U2010257                 |" << endl;
        cout << " ----------------------------------------------" << endl;
        cout << "|:::::::: Flyght Ticket Booking System ::::::::|" << endl;
        cout << " ----------------------------------------------" << endl;
        Sleep(4000);
    }

    void exitProgram()
    {
        system("cls");
        cout << " ----------------------------------------------" << endl;
        cout << "|=========| THANKS FOR THE ATTENTION |=========|" << endl;
        cout << " ----------------------------------------------" << endl;
        Sleep(2000);
        exit(0);
    }
};

class Application
{
public:
    virtual void handleMenu() = 0;
};

int main()
{
    Application *app;
    bool switcher = true;

    while (1 != 2)
    {
        switcher = !switcher;
        
        if (switcher)
        {
            app = new ClientApp();
        }
        else
        {
            app = new AdminApp();
        }
       
        app->handleMenu();
    }
    
    return 777;
}