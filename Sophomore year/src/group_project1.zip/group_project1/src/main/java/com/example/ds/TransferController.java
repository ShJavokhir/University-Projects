package com.example.ds;

import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class TransferController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TextField cardNumber;
    @FXML
    private TextField amount;
    @FXML
    private Label balance;


    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToScene2(ActionEvent event) throws IOException {


        Parent root = FXMLLoader.load(getClass().getResource("Transfer.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToScene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("History.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void initialize() throws UnirestException {
        String balance = "$" + Unirest.post(ApiEndpoints.GET_BALANCE_API)
                .header("accept", "application/json")
                .field("cardExpiryDate", CardCredentials.CARD_EXPIRY_DATE)
                .field("cardNumber", CardCredentials.CARD_NUMBER)
                .field("cardCvv", CardCredentials.CARD_CVV).asJson().getBody().getObject().get("balance");
        this.balance.setText(balance);

        cardNumber.setText("9233768531879673");
        amount.setText("1");

    }

    public void transferMoney() throws UnirestException {
        System.out.println("Card number to transfer: " + cardNumber.getText());
        System.out.println("Amount to transfer: " + amount.getText());

        System.out.println(Unirest.post(ApiEndpoints.TRANSFER_MONEY_API)
                .header("accept", "application/json")
                .field("cardExpiryDateToTransfer", CardCredentials.CARD_EXPIRY_DATE)
                .field("cardNumberToTransfer", CardCredentials.CARD_NUMBER)
                .field("cardCvvToTransfer", CardCredentials.CARD_CVV)
                .field("cardToReceive", cardNumber.getText())
                .field("amountToTransfer", amount.getText())
                .asJson().getBody());
        String balance = "$" + Unirest.post(ApiEndpoints.GET_BALANCE_API)
                .header("accept", "application/json")
                .field("cardExpiryDate", CardCredentials.CARD_EXPIRY_DATE)
                .field("cardNumber", CardCredentials.CARD_NUMBER)
                .field("cardCvv", CardCredentials.CARD_CVV).asJson().getBody().getObject().get("balance");
        this.balance.setText(balance);

    }

}
