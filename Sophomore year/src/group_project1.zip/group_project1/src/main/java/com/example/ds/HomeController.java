package com.example.ds;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONObject;


import java.io.IOException;
import java.util.ArrayList;


public class HomeController {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button history1;

    @FXML
    private Button transfer1;

    @FXML
    private Label balance;

    @FXML
    private Label cashback;

    @FXML
    private Label myCardLabel;


    @FXML
    public void initialize() throws UnirestException {
        System.out.println("Home page init");
        String balance = "$" + Unirest.post(ApiEndpoints.GET_BALANCE_API)
                .header("accept", "application/json")
                .field("cardExpiryDate", CardCredentials.CARD_EXPIRY_DATE)
                .field("cardNumber", CardCredentials.CARD_NUMBER)
                .field("cardCvv", CardCredentials.CARD_CVV).asJson().getBody().getObject().get("balance");
        String cashback = "$" + Unirest.post(ApiEndpoints.GET_CASHBACK_API)
                .header("accept", "application/json")
                .field("cardExpiryDate", CardCredentials.CARD_EXPIRY_DATE)
                .field("cardNumber", CardCredentials.CARD_NUMBER)
                .field("cardCvv", CardCredentials.CARD_CVV).asJson().getBody().getObject().get("cashBack");
        System.out.println("Balance: " + balance + " | Cashback: " + cashback);

        //System.out.println(historyPayments.size());
        //results.forEach(history: );
//        while(results.iterator() != null){
//            results.
//            if(results.iterator().hasNext()){
//                results.iterator().next();
//            }else{
//                break;
//            }
//        }
//        System.out.println(results.getJSONObject(0).toString());




        this.balance.setText(balance);
        this.cashback.setText(cashback);
        this.myCardLabel.setText("MyCard: " + CardCredentials.CARD_NUMBER);
    }

    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToScene2(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Transfer.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToScene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("History.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}